
// PCLDialogDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PCLDialog.h"
#include "PCLDialogDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CPCLDialogDlg dialog



CPCLDialogDlg::CPCLDialogDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CPCLDialogDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	//��pcl::mfc_visualization::PCLVisualizerj���г�ʼ��
	this->viewer = NULL;

	sensor_origin = Eigen::Vector4f::Zero();
	sensor_orientation = Eigen::Quaternionf::Identity();
}

void CPCLDialogDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CPCLDialogDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_OPENPCD, &CPCLDialogDlg::OnBnClickedOpenpcd)
END_MESSAGE_MAP()


// CPCLDialogDlg message handlers

BOOL CPCLDialogDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	//��PictControl�ؼ�IDC_PCDVIEWER���ھ��������ͼ�����viewer
	CWnd *viewer_pcWnd; 
	viewer_pcWnd = this->GetDlgItem(IDC_PCDVIEWER);
	this->viewer = new pcl::mfc_visualization::PCLVisualizer(viewer_pcWnd);

	CRect cRectPCL;
	this->viewer->GetClientRect(&cRectPCL);

	CRect cRectClient;
	GetClientRect(&cRectClient);

	this->ptBorder.x = cRectClient.Width() - cRectPCL.Width();
	this->ptBorder.y = cRectClient.Height() - cRectPCL.Height();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPCLDialogDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPCLDialogDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPCLDialogDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CPCLDialogDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	//ʵ��picture control���������洰�ڱ任��С
	if (::IsWindow(this->GetSafeHwnd()))
	{
		if (this->viewer)
		{
			cx -= ptBorder.x;
			cy -= ptBorder.y;
			this->GetDlgItem(IDC_PCDVIEWER)->SetWindowPos(NULL, 0, 0, cx, cy, SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOMOVE);
			this->viewer->SetWindowPos(NULL, 0, 0, cx, cy, SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOMOVE);
		}
	}
}


void CPCLDialogDlg::OnBnClickedOpenpcd()
{
	// TODO: Add your control notification handler code here
	this->viewer->removeAllPointClouds();

	// TODO: Add your control notification handler code here
	static TCHAR BASED_CODE szFilter[] = _T("PCD (*.pcd )|*.pcd||");
	CFileDialog cFileDialog(true, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR, szFilter);

	if (cFileDialog.DoModal() == IDOK)
	{
		/////////////////////////////////////////////////////////////////////////////
		//�ĵ�����
		std::string filename;
		
#ifdef _UNICODE
		CString cstring = cFileDialog.GetFileName();
		filename = (LPCSTR)CStringA(cstring); 		
#else
		filename = cFileDialog.GetFileName().GetBuffer(0);
#endif
		
		

		//reset data
		this->binary_blob.reset();
		binary_blob = pcl::PCLPointCloud2::Ptr(new pcl::PCLPointCloud2);
		// read new data
		//*.pcd�ļ�
		pcl::PCDReader pcd_reader;
		if (pcd_reader.read((char*)_bstr_t(filename.c_str()), *binary_blob) != 0) //* load the file
		{
			MessageBox(_T("Couldn't read PCData file!"));
			return;
		}
	}
	if (binary_blob == NULL)
	{
		MessageBox(_T("Please load PCD file firstly!"));
		return;
	}
	else
	{
		//�������
		if (pcl::getFieldIndex(*binary_blob, "rgb") > 0)
		{
			color_Handler = pcl::mfc_visualization::PointCloudColorHandlerRGBField<pcl::PCLPointCloud2>::Ptr
				(new pcl::mfc_visualization::PointCloudColorHandlerRGBField<pcl::PCLPointCloud2>(binary_blob));
			this->viewer->addPointCloud(binary_blob, color_Handler, sensor_origin, sensor_orientation);
		}
		else
		{
			xyz_Handler = pcl::mfc_visualization::PointCloudGeometryHandlerXYZ<pcl::PCLPointCloud2>::Ptr
				(new pcl::mfc_visualization::PointCloudGeometryHandlerXYZ<pcl::PCLPointCloud2>(binary_blob));
			this->viewer->addPointCloud(binary_blob, xyz_Handler, sensor_origin, sensor_orientation);
		}
		this->viewer->resetCamera();
	}
}


void CPCLDialogDlg::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class

	delete viewer;

	CDialogEx::OnOK();
}
