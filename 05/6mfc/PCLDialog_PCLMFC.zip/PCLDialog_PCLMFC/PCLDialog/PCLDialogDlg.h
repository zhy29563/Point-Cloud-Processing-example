
// PCLDialogDlg.h : header file
//

#pragma once
#include "pcl\point_cloud.h"
#include "pcl\point_types.h"
#include "pcl\mfc_visualization_1_6\pcl_visualizer.h"
#include "vtkRenderer.h"
#include <pcl/io/pcd_io.h>

// CPCLDialogDlg dialog
class CPCLDialogDlg : public CDialogEx
{
// Construction
public:
	CPCLDialogDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_PCLDIALOG_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

private:
	//��ͼ����
	pcl::mfc_visualization::PCLVisualizer *viewer;
	vtkRenderer *pvtkRenderer;
	POINT  ptBorder;

	//���ݵ�
	pcl::PCLPointCloud2::Ptr binary_blob;
	//���ݵ���
	pcl::mfc_visualization::PointCloudGeometryHandlerXYZ<pcl::PCLPointCloud2>::Ptr xyz_Handler;
	pcl::mfc_visualization::PointCloudColorHandlerRGBField<pcl::PCLPointCloud2>::Ptr color_Handler;
	//������λ�÷������
	Eigen::Vector4f sensor_origin;
	Eigen::Quaternion<float> sensor_orientation;

public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedOpenpcd();
	virtual void OnOK();
};
